//Q1_1

#include <stdio.h>

void main() {
	printf("*******************\n");
	printf("My First Program!!!\n");
	printf("Last name: Butov\n");
	printf("First name: Pavel\n");
	printf("ID Number: 317552636\n");
	printf("*******************\n\n");

}