//Q1_2
#include <stdio.h>

void main() {

	//printf("  @\n @@@\n@@@@@\n @@@\n  @\n");
	printf("12345\n 678\n  9\n");

}